
#include "mem.h"
#include "stdlib.h"
#include "string.h"
#include <pthread.h>
#include <stdio.h>

static BYTE _ram[RAM_SIZE];

static struct {
	uint32_t proc;	// ID of process currently uses this page
	int index;	// Index of the page in the list of pages allocated
			// to the process.
	int next;	// The next page in the list. -1 if it is the last
			// page.
} _mem_stat [NUM_PAGES];

static pthread_mutex_t mem_lock;

void init_mem(void) {
	memset(_mem_stat, 0, sizeof(*_mem_stat) * NUM_PAGES);
	memset(_ram, 0, sizeof(BYTE) * RAM_SIZE);
	pthread_mutex_init(&mem_lock, NULL);
}

/* get offset of the virtual address */
static addr_t get_offset(addr_t addr) {
	return addr & ~((~0U) << OFFSET_LEN);
}

/* get the first layer index */
static addr_t get_first_lv(addr_t addr) {
	return addr >> (OFFSET_LEN + PAGE_LEN);
}

/* get the second layer index */
static addr_t get_second_lv(addr_t addr) {
	return (addr >> OFFSET_LEN) - (get_first_lv(addr) << PAGE_LEN);
}

/* Search for page table table from the a segment table */
static struct page_table_t * get_page_table(
		addr_t index, 	// Segment level index
		struct seg_table_t * seg_table) { // first level table
	
	/*
	 * TODO: Given the Segment index [index], you must go through each
	 * row of the segment table [seg_table] and check if the v_index
	 * field of the row is equal to the index
	 *
	 * */

	int i;
	
	for (i = 0; i < seg_table->size; i++) {
		// Enter your code here
		
		if(seg_table->table[i].v_index==index){
		
		    return seg_table->table[i].pages;
		
		}
		
	}
	return NULL;

}

/* Translate virtual address to physical address. If [virtual_addr] is valid,
 * return 1 and write its physical counterpart to [physical_addr].
 * Otherwise, return 0 */
static int translate(
		addr_t virtual_addr, 	// Given virtual address
		addr_t * physical_addr, // Physical address to be returned
		struct pcb_t * proc) {  // Process uses given virtual address

	/* Offset of the virtual address */
	addr_t offset = get_offset(virtual_addr);
	/* The first layer index */
	addr_t first_lv = get_first_lv(virtual_addr);
	/* The second layer index */
	addr_t second_lv = get_second_lv(virtual_addr);
	
	/* Search in the first level */
	struct page_table_t * page_table = NULL;
	page_table = get_page_table(first_lv, proc->seg_table);
	if (page_table == NULL) {
		return 0;
	}

	int i;
	for (i = 0; i < page_table->size; i++) {
		if (page_table->table[i].v_index == second_lv) {
			/* TODO: Concatenate the offset of the virtual addess
			 * to [p_index] field of page_table->table[i] to 
			 * produce the correct physical address and save it to
			 * [*physical_addr]  */
			 
			 *physical_addr = (page_table->table[i].p_index<<OFFSET_LEN)|offset;
			 
			return 1;
		}
	}
	return 0;	
}








int check_mem_avail(struct pcb_t * proc, uint32_t num_pages, uint32_t *head_index)
{


	
	if(proc->bp + num_pages*PAGE_SIZE >= RAM_SIZE)return 0;
	
	
	int count_page=0;
	
	int prev_mem_stat=-1;
	
	
	//Count available phisical memory
	
	
	
	for(int i=0; i<NUM_PAGES; i++)
	{
	
	
		if(!_mem_stat[i].proc)
		{
			
			count_page++;
			
			if(prev_mem_stat==-1){  
			
			    *head_index = i; 
			    
			 }
			 else{
			
			   _mem_stat[prev_mem_stat].next = i;
			
			}
	
	
			prev_mem_stat=i;	
			
			
			if(count_page==num_pages){ 
			
			  _mem_stat[i].next = -1;  
			    
			  return 1;
			    
			}
			
			
		}
	
	}
	
	
	
	return 0;

}






addr_t alloc_mem(uint32_t size, struct pcb_t * proc) {
	pthread_mutex_lock(&mem_lock);
	addr_t ret_mem = 0;
	/* TODO: Allocate [size] byte in the memory for the
	 * process [proc] and save the address of the first
	 * byte in the allocated memory region to [ret_mem].
	 * */
	 
	 
	uint32_t num_pages = (size % PAGE_SIZE)?size/PAGE_SIZE +1 :size / PAGE_SIZE; // Number of pages we will use
	
	
	int mem_avail = 0; // We could allocate new memory region or not?

	/* First we must check if the amount of free memory in
	 * virtual address space and physical address space is
	 * large enough to represent the amount of required 
	 * memory. If so, set 1 to [mem_avail].
	 * Hint: check [proc] bit in each page of _mem_stat
	 * to know whether this page has been used by a process.
	 * For virtual memory space, check bp (break pointer).
	 * */
	 
	
	 uint32_t traverse;
	
	 
	 
	 mem_avail = check_mem_avail(proc,num_pages, &traverse);
	 
	 
	
	if (mem_avail) {
		/* We could allocate new memory region to the process */
		ret_mem = proc->bp;
		proc->bp += num_pages * PAGE_SIZE;
		/* Update status of physical pages which will be allocated
		 * to [proc] in _mem_stat. Tasks to do:
		 * 	- Update [proc], [index], and [next] field
		 * 	- Add entries to segment table page tables of [proc]
		 * 	  to ensure accesses to allocated memory slot is
		 * 	  valid. */
		
		 for(int i=0; i< num_pages; i++)
		 {
		 
		 	addr_t virtual_addr = ret_mem + i*PAGE_SIZE;
		 
		 	addr_t first_lv = get_first_lv(virtual_addr);
		 	
		 	addr_t second_lv = get_second_lv(virtual_addr);
		 
		 	struct page_table_t * page_table = NULL;
		 	
			page_table = get_page_table(first_lv, proc->seg_table);
		 
		 
		 	int page_pos;
				
			
		 	if(page_table != NULL){
		 		
		 		page_pos = page_table->size++;
		 		
		 		page_table->table[page_pos].v_index = second_lv;
		 		
		 		page_table->table[page_pos].p_index = traverse;
		 		
		 	}
		 	else
		 	{
		 		int seg_pos;
				
		 		page_table = (struct page_table_t*)malloc(sizeof(struct page_table_t));
		 		
		 		page_pos = page_table->size++;
		 		
		 		page_table->table[page_pos].v_index = second_lv;
		 		
		 		page_table->table[page_pos].p_index = traverse;
		 		
		 		seg_pos = proc->seg_table->size++;
		 		
		 		proc->seg_table->table[seg_pos].v_index = first_lv;
		 		
		 		proc->seg_table->table[seg_pos].pages = page_table;
		 			
		 	}
		 	
		 	_mem_stat[traverse].proc = proc->pid;
		 
		 	_mem_stat[traverse].index = i;
		 		 	
		 	traverse = _mem_stat[traverse].next;
		 
		 }
		  
	}
	pthread_mutex_unlock(&mem_lock);
	return ret_mem;
}




int free_mem(addr_t address, struct pcb_t * proc) {
	/*TODO: Release memory region allocated by [proc]. The first byte of
	 * this region is indicated by [address]. Task to do:
	 * 	- Set flag [proc] of physical page use by the memory block
	 * 	  back to zero to indicate that it is free.
	 * 	- Remove unused entries in segment table and page tables of
	 * 	  the process [proc].
	 * 	- Remember to use lock to protect the memory from other
	 * 	  processes.  */
	 
	
	 
pthread_mutex_lock(&mem_lock);
  
  
	 addr_t v_address = address;
	 
	 struct page_table_t *page_table = NULL;
	 
	 addr_t first_lv;
	 
	 addr_t second_lv;
	 
	 addr_t current_address;
	 
	 addr_t p_address;
	 
	 int i=0;
	 	 

	do{
		current_address = v_address + (i++)*PAGE_SIZE;
	
		first_lv = get_first_lv(current_address);
		
		second_lv = get_second_lv(current_address);
	
		page_table = get_page_table(first_lv, proc->seg_table);
		
		if(page_table==NULL){
		
			pthread_mutex_unlock(&mem_lock);
			
			return 1;
		
		}
		
		
		//clear logical page
		
		
		for(int j=0; j< page_table->size; j++)
		{
			
			if(second_lv == page_table->table[j].v_index)
			{
				
		       	p_address = page_table->table[j].p_index;
				
				page_table->table[j] = page_table->table[--page_table->size];
				
				break;
				
			}
			
			if(j== page_table->size-1){
			
				pthread_mutex_unlock(&mem_lock);
				
				return 1;
			
			}
	
		}
		
		
		
		if(page_table->size==0)
		{
		
		for(int j=0; j< proc->seg_table->size; j++)
	
			if(proc->seg_table->table[j].v_index == first_lv)
			{

				free(proc->seg_table->table[j].pages);
				
				proc->seg_table->table[j].pages = NULL;
				
				proc->seg_table->table[j].v_index = 0;
				
				break;
				
			}
		
		}
		
		
		//clear physical page
		
		
		_mem_stat[p_address].proc = 0;
		
		if(_mem_stat[p_address].next == -1)
		{
		
			break;
		}
		
		
	}while(1);
	 
	
	 
pthread_mutex_unlock(&mem_lock);
	 
	 
	 
	return 0;
}

int read_mem(addr_t address, struct pcb_t * proc, BYTE * data) {
	addr_t physical_addr;
	if (translate(address, &physical_addr, proc)) {
		*data = _ram[physical_addr];
		return 1;
	}else{
		return 0;
	}
}

int write_mem(addr_t address, struct pcb_t * proc, BYTE data) {


	addr_t physical_addr;
	if (translate(address, &physical_addr, proc)) {
	
		_ram[physical_addr] = data;	
		return 0;
	}else{
		return 1;
	}
}

void dump(void) {
	int i;
	for (i = 0; i < NUM_PAGES; i++) {
		if (_mem_stat[i].proc != 0) {
		
			printf("%03d: ", i); 
			
			printf("%05x-%05x - PID: %02d (idx %03d, nxt: %03d)\n",
				i << OFFSET_LEN,
				((i + 1) << OFFSET_LEN) - 1,
				_mem_stat[i].proc,
				_mem_stat[i].index,
				_mem_stat[i].next
			);
			
			
			int j;
			for (	j = i << OFFSET_LEN;
				j < ((i+1) << OFFSET_LEN) - 1;
				j++) {
				
				if (_ram[j] != 0) {
				
					printf("\t%05x: %02x\n", j, _ram[j]);
					
				}
					
			}
		}
	}
}


